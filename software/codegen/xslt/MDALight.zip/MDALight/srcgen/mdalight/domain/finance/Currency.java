package mdalight.domain.finance;

public enum Currency {
    euro,
    dollar,
    pound
}
