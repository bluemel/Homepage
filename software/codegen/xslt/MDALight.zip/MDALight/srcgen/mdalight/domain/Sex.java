package mdalight.domain;

public enum Sex {
    male,
    female,
    unknown
}
