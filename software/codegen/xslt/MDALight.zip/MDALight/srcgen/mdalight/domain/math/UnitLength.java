package mdalight.domain.math;

public enum UnitLength {
    kilometers,
    meters,
    decimeters,
    centimeters,
    millimeters,
    micrometers,
    nanometers,
    picometers
}
