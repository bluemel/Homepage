package mdalight;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;
import org.apache.tools.ant.types.FileSet;

public class FileCatalog extends Task {

	private File outfile;

	public void setOutfile(File file) {
		this.outfile = file;
	}

	private String rootelement;

	public void setRootelement(String root) {
		this.rootelement = root;
	}

	private ArrayList<FileSet> filesets = new ArrayList<FileSet>();

	public void addFileset(FileSet set) {
        this.filesets.add(set);
    }

	public void execute() {
		if (this.outfile == null) {
			throw new BuildException(
					"mandatory property \"outfile\" not defined");
		}
		if (!this.outfile.getParentFile().exists()) {
			throw new BuildException("parent folder of outfile \""
					+ this.outfile + "\" does not exist");
		}
		FileWriter fw = null;
		try {
			fw = new FileWriter(this.outfile);
			fw.write("<?xml version=\"1.0\"?>\n");
			fw.write("<" + this.rootelement +">\n");
			for (FileSet set : this.filesets) {
				for (String filename : set.getDirectoryScanner(this.getProject()).getIncludedFiles()) {
	                File file = new File(filename);
	                fw.write("\t<file dir=\"" + file.getParent() + "\" name=\"" + file.getName() + "\"/>\n");
				}
			}
			fw.write("</" + this.rootelement +">\n");
		} catch (IOException e) {
			throw new BuildException(e);
		} finally {
			if (fw != null) {
				try {
					fw.close();
				} catch (IOException e) {
					throw new BuildException(e);
				}
			}
		}
	}
}
