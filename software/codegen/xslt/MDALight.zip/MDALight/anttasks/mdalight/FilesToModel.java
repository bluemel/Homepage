package mdalight;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;
import org.apache.tools.ant.types.FileSet;

public class FilesToModel extends Task {

	private File outfile;

	public void setOutfile(File file) {
		this.outfile = file;
	}

	private String rootelement = "model";

	public void setRootelement(String root) {
		this.rootelement = root;
	}

	private String element;

	public void setElement(String elem) {
		this.element = elem;
	}

	private ArrayList<FileSet> filesets = new ArrayList<FileSet>();

	public void addFileset(FileSet set) {
        this.filesets.add(set);
    }

	public void execute() {
		if (this.outfile == null) {
			throw new BuildException(
					"mandatory property \"outfile\" not defined");
		}
		if (!this.outfile.getParentFile().exists()) {
			throw new BuildException("parent folder of outfile \""
					+ this.outfile + "\" does not exist");
		}
		FileWriter fw = null;
		try {
			fw = new FileWriter(this.outfile);
			fw.write("<?xml version=\"1.0\"?>\n");
			fw.write("<" + this.rootelement +">\n");
			for (FileSet set : this.filesets) {
				final File root = set.getDir(this.getProject());
				writeModel(fw, root, 0, "\t");
			}
			fw.write("</" + this.rootelement +">\n");
		} catch (IOException e) {
			throw new BuildException(e);
		} finally {
			if (fw != null) {
				try {
					fw.close();
				} catch (IOException e) {
					throw new BuildException(e);
				}
			}
		}
	}

	final void writeModel(FileWriter fw, File dir, int depth, String indent) throws IOException {
		for (File file : dir.listFiles()) {
			if (file.isDirectory()) {
				fw.write(indent + "<package name=\""
						+ file.getName().substring(0, file.getName().length())
						+ "\">\n");				
				writeModel(fw, file, depth + 1, indent + "\t");
				fw.write(indent + "</package>\n");				
			} else if (file.getName().endsWith(".xml")) {
				fw.write(indent + "<" + element + " name=\""
						+ file.getName().substring(0, file.getName().length() - 4)
						+ "\"/>\n");
			}
		}
	}
}
