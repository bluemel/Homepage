package mdalight;

import javax.swing.JTree;

import org.rapidbeans.core.basic.RapidBean;
import org.rapidbeans.datasource.Document;
import org.rapidbeans.presentation.Application;
import org.rapidbeans.presentation.ApplicationManager;
import org.rapidbeans.presentation.DocumentView;
import org.rapidbeans.presentation.swing.DocumentTreeViewSwing;


/**
 * @author Martin Bluemel
 */
public class MdaLightApplication extends Application {
    public static void main(final String[] args) {
        ApplicationManager.start("mdalight/MdaLightApplication.xml");
    }

    public void init() {
        super.init();
        final DocumentView view = this.openDocumentView(new Document(
        		RapidBean.createInstance("mdalight.domain.TestMda")));
        final DocumentTreeViewSwing treeView = (DocumentTreeViewSwing) view.getTreeView();
        final JTree tree = (JTree) treeView.getTree();
        tree.setSelectionPath(tree.getPathForRow(0));
        treeView.editBeans();
    }
}
