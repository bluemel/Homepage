/*
 * SexTest.java 
 */
package mdalight.domain;

import static org.junit.Assert.*;

import mdalight.domain.Sex;

import org.junit.Test;


/**
 * @author bm092114
 */
public class SexTest {

	/**
	 * Test method for {@link easybiz.core.basic.BBEnum#toString()}.
	 */
	@Test
	public void testToString() {
		assertEquals("male", Sex.male.toString());
		assertEquals("female", Sex.female.toString());
	}

	/**
	 * Test method for {@link easybiz.core.basic.BBEnum#ordinal()}.
	 */
	@Test
	public void testOrdinal() {
		assertEquals(0, Sex.male.ordinal());
		assertEquals(1, Sex.female.ordinal());
	}

	/**
	 * Test method for {@link java.lang.Object#equals(java.lang.Object)}.
	 */
	@Test
	public void testEquals() {
		final Sex male = Sex.male;
		assertEquals(Sex.male, male);
		assertFalse(Sex.male.equals(Sex.female));
	}
	
	/**
	 * Test method for {@link easybiz.core.basic.BBEnum#compareTo(java.lang.Object)}.
	 */
	@Test
	public void testCompareTo() {
		assertEquals(-1, Sex.male.compareTo(Sex.female));
		assertEquals(1, Sex.female.compareTo(Sex.male));
	}

//	/**
//	 * Test usage in a switch (Java 4).
//	 */
//	@Test
//	public void testSwitchJava4() {
//		Sex sex = Sex.female;
//		switch (sex.ordinal()) {
//		case Sex.ORDINAL_MALE:
//			fail("expected FEmale not male");
//			break;
//		case Sex.ORDINAL_FEMALE:
//			break;
//		}
//	}

	/**
	 * Test usage in a switch (Java 5).
	 */
	@Test
	public void testSwitchJava5() {
		Sex sex = Sex.female;
		switch (sex) {
		case male:
			fail("expected female not male");
			break;
		case female:
			break;
		}
	}
}
