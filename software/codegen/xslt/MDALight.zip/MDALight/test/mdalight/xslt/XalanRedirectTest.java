/*
 * XalanRedirectTest.java 
 */
package mdalight.xslt;

import java.io.File;

import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.junit.Test;


/**
 * Test Xalans Redirect possibilities
 */
public class XalanRedirectTest {

	/**
	 * Test Xalan redirect
	 * @throws TransformerException if transformation fails
	 */
	@Test
	public void testRedirect() throws TransformerException {
//		XSLTProcess xsltTask = new XSLTProcess();
//		Project project = new Project();
//		xsltTask.setProject(project);
//		xsltTask.setIn(new File("model/catalogEnums.xml"));
//		xsltTask.setOut(new File("reports/enums.html"));
//		xsltTask.setStyle("templates/enumreport_html_multi.xsl");
//		xsltTask.execute();
        Source xmlSource = new StreamSource(new File("model/catalogEnums.xml"));
        Source xsltSource = new StreamSource(new File("templates/enumreport_html_multi.xsl"));
        TransformerFactory transFact = TransformerFactory.newInstance();
        Transformer trans = transFact.newTransformer(xsltSource);
        File basedir = new File(".");
        trans.setParameter("modelhome", new File(basedir, "model" + File.separatorChar + "enums").getAbsolutePath());
        trans.setParameter("reportshome", new File(basedir, "reports").getAbsolutePath());
        trans.transform(xmlSource, new StreamResult(new File("reports/enums.html")));
	}
}
